# MODE A — Build from blank

Read `prompts/00_SHARED_INSTRUCTIONS.md` first. **Goal:** build a new five-screen Power Apps Canvas UI matching `references/01_home.jpg` through `05_submission_complete.jpg` as closely as practical.

1. Verify whether an editable blank development Canvas app is accessible; identify supported MCP/skills editing operations. If not, provide a supported manual or source-based implementation plan.
2. Plan a shared header, central theme tokens, replaceable asset references and reusable components per `specs/COMPONENTS.md`. Obtain approved logo/media where required; use clearly identified placeholders otherwise.
3. Build `scrHome`, `scrQmidSearch`, `scrQuestionnaire`, `scrEvidence`, `scrComplete` in order; use `specs/SCREENS.md` for exact labels, controls and mock states. All form fields must be native controls. Use responsive containers and screen-reader labels.
4. Demo data only: QMID temp00037, submitted ID 37, draft ID 36. For UI-only actions that need a backend (email/download), show explicit demo-only feedback; never fake a completed action.
5. Wire navigation and local draft/questionnaire state. Support per-question rationale configuration for future use but do not force it into the reference screen unless specified.
6. After each screen capture runtime screenshot, compare with its reference, log deviations, refine and run `qa/ACCEPTANCE.md`.
7. Deliver reusable theme/components, mock data definition, implementation log and any manual Power Apps Studio steps.

Do not add SharePoint or flows, deploy a backend, or publish production without separate approval. Begin with a capability assessment and build plan.
