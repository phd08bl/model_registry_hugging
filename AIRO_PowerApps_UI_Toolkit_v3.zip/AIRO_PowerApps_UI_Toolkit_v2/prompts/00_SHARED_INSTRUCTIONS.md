# Common Copilot instructions — apply to all modes

You are implementing an AIASO-branded, SAP Fiori-inspired UI for AIRO Triage in Power Apps Canvas. Read `README.md`, `specs/DESIGN.md`, `specs/SCREENS.md`, `specs/COMPONENTS.md`, `specs/POWER_APPS_ARCHITECTURE.md`, `specs/CHANGE_POLICY.md`, `config/theme.tokens.json`, `config/asset-manifest.json`, and all five `references/*.jpg` images. If `external/SAP_DESIGN.md` is available, use it for secondary design guidance, not as a replacement for approved AIASO tokens.

Start by discovering and reporting the available Power Apps skills/MCP actions and actual app access. Never claim that unsupported operations were performed. Do not publish or deploy to production. For all modes, preserve business controls and accessibility, implement native controls rather than full-screen screenshot images, centralise theme/media, keep change log and acceptance evidence. Pause for approval before destructive or functional changes.

Deliver: capability report, proposed plan, implementation/change log, screenshot comparisons, functional test results, known gaps and next steps.
