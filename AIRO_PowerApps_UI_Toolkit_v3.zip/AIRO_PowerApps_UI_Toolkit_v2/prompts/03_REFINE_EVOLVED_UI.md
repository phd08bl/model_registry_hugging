# MODE C — Refine UI after functionality changes

Read `prompts/00_SHARED_INSTRUCTIONS.md` first. **Goal:** make an evolved AIRO Triage app visually consistent with the AIASO design system while retaining *all* new and old features.

1. Inspect current live development version and compare it with previous approved state, the five baseline screenshots, and current requirements. Identify added screens, fields, questions, rationale inputs, attachments, reviewer controls, error states and navigation changes.
2. Complete `templates/FEATURE_EXTENSION.md` for each change; classify visual (V), layout (L), functional (F) or brand (B) per `specs/CHANGE_POLICY.md`. Do not infer new business policy from a screenshot.
3. Map every new control to the design tokens and reusable components. Extend component variants for new control types; preserve actual Power Fx formulas and permissions.
4. Propose layout treatment for new features (e.g., rationale textbox below relevant question, optional evidence upload area, new reviewer panel), keeping typography, spacing, info/error banners and status semantics consistent. New functionality takes precedence over pixel-for-pixel matching to outdated screenshots.
5. Request approval for any functional or destructive changes. Implement style-only changes in a development copy, one screen at a time.
6. Run screenshot visual QA for unchanged baseline areas and style consistency QA for newly added areas; perform functional regression and accessibility checks.
7. Update screen extension records and design tokens only if an approved design-system change is warranted; do not silently alter the baseline references.

Deliver a before/after change map, component reuse decisions, screenshots, test outcomes and list of design deviations. Start with a current-state inventory and a no-code-change proposal.
