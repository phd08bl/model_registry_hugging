# MODE B — Modernise existing application

Read `prompts/00_SHARED_INSTRUCTIONS.md` first. **Goal:** visually modernise an existing working AIRO Triage Canvas app to match the approved reference images without changing behaviour.

1. Confirm target app/environment and use a backed-up development copy. Inventory actual screens, controls, Power Fx formulas, component references, connections, data schemas, Power Automate flows, role checks and navigation. Populate `templates/APP_DISCOVERY.md`.
2. Map current screens and controls to `specs/SCREENS.md` and `references/*.jpg`. Populate `templates/CONTROL_MAPPING.csv` with actual control names and protected properties. Flag missing or additional functionality.
3. Produce a screen-by-screen plan: visual property edits first; container/layout restructuring only where necessary; component replacements only after formula dependency review. Ask for approval before editing.
4. Implement central `gblTheme`/named formulas and media aliases, shared AIASO header, consistent cards, buttons, status pills and field styles. **Preserve OnSelect, OnChange, Items, Default, Update, Visible, DisplayMode, data bindings and validation logic** unless specifically authorised.
5. Keep existing screens, IDs and workflows; do not rename or remove controls just to match screenshots. Preserve any newly added required fields, including rationale.
6. Compare screenshots and run regression tests for QMID search, saved/submitted records, draft, form validation, email identity, submit, navigation and download/email where implemented.
7. Report exact changes, formulas touched, functional tests and visual deviations. Do not publish production.

If MCP cannot inspect/edit the app, stop at a documented plan and property-level instructions; do not claim a live update. Start with discovery only.
