# MASTER PROMPT — paste into GitHub Copilot CLI

You are a senior Microsoft Power Apps Canvas engineer and enterprise UI designer. Build **UI ONLY** for the AIRO Triage app in the currently connected **development** Power Apps environment, using the installed Canvas Apps skills and MCP tools. Do not add SharePoint, Dataverse, PostgreSQL, Power Automate, MARM, or any backend connection. Do not deploy or publish to production.

Read these local files completely before acting:
- `specs/DESIGN.md`
- `specs/SCREENS.md`
- `specs/IMPLEMENTATION.md`
- `references/01_home.jpg` through `references/05_submission_complete.jpg`
- `assets/` folder
- If present, `external/SAP_DESIGN.md` (the original SAP design.md from the voltagent/awesome-design-md repo). Apply its Fiori principles where compatible with approved reference screens. Never claim to have read it if absent.

OBJECTIVE: Visually reproduce all five approved reference screens in a genuine editable Canvas app. Every visible text label, form field, table, card, progress bar and button must be a native Power Apps control/component. Do NOT place entire screenshots behind invisible buttons. Decorative raster assets only for logos, artwork and textures. Brand must be easily replaceable.

WORKFLOW — STOP AND REPORT AT EACH PHASE:
A. Discover: list actual installed Canvas Apps skills, accessible MCP actions, app/solution/environment and edit capabilities. Inspect existing app and avoid overwriting unrelated screens. Confirm you are working in a development environment. Report blockers; never invent tool actions.
B. Plan: map screen references to `scrHome`, `scrQmidSearch`, `scrQuestionnaire`, `scrEvidence`, `scrComplete`. Propose component tree, assets, local mock data, navigation and theme. Show the plan before changing app.
C. Foundation: import approved media assets, create central `gblTheme` record, local mock collections and shared `cmpHeader`. The header must have the correct AIASO logo, 'AI Analytics, Strategy & Oversight' and 'AIRO Triage', dark charcoal band and subtle dotted texture. Replace the raster reference logo with official media if supplied.
D. Build screens **one at a time in the exact order** 1–5, using `specs/SCREENS.md` and corresponding screenshot. Use reusable components and responsive containers. After each screen, read back controls/properties, preview and capture a screenshot where supported, and report differences from reference before continuing.
E. Wire UI-only navigation and mock behaviour. All visible buttons must do something meaningful; for actions needing backend integration show honest demo-only notifications. Preserve disabled/error states, search filter, draft/submitted statuses, progress and validation.
F. QA: check each screen against the reference and run visual, responsive, keyboard/accessibility and navigation tests. Report exact items matched, deviations and limitations. Save app changes only after verifying in the correct environment.

DESIGN NON-NEGOTIABLES:
- Keep the 5-screen layout and exact functional scope shown; no extra dashboard or navigation sidebar.
- Consistent charcoal halftone header on all screens.
- Navy headings, emerald green CTAs, Fiori-blue informational accents, pale blue canvas, white rounded cards.
- Use native editable Power Apps UI, not flattened screenshots.
- Centralised theme, media aliases and reusable components so logo, background, fonts and colours can be swapped later.
- Preserve QMID temp00037, Assessment ID 37 and 36 as mock examples; do not confuse them with live governance records.
- For Questionnaire, preserve three exact questions, multi-select Q2, help text Q1, progress, Save Draft and Submit form.
- For Evidence, preserve error banner and disabled Submit until account email matches. No actual submission in UI-only mode.
- For Complete, preserve three actions; don't claim email/download happened.
- Never guess policy-defined answer choices. Use placeholder options only when clearly labelled demo; ask for actual questionnaire options before production.

OUTPUT: Power Apps dev app changes (if tools support), plus a concise control/component inventory, formulas, asset list, screen screenshots, deviations, and instructions to replace the theme/logo later. If tool capabilities are insufficient, produce implementation-ready source instructions and explicitly state which steps require Power Apps Studio.

START NOW WITH PHASE A ONLY. Do not change the app until discovery and plan are reviewed.
