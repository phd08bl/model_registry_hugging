# Acceptance checklist

## Capability and safety
- [ ] Correct environment/app confirmed; actual skills/MCP capabilities verified
- [ ] Development copy/backup established for existing app
- [ ] No unauthorised data schema, flow, deployment or production changes
- [ ] No unverified claim of email/download or backend integration

## Design system
- [ ] Shared AIASO header across all five screens; logo/media centrally replaceable
- [ ] Central theme tokens applied; no unexplained screen-level colour overrides
- [ ] Native controls, not full-screen screenshots
- [ ] Fonts, spacing, borders, status colours and action styles consistent
- [ ] Approved media/licensing checked; decorative assets do not carry text

## Screen visuals
- [ ] Home cards, titles, branding and background match reference
- [ ] QMID search, Submitted/Draft tables and New action match reference
- [ ] Questionnaire progress, question cards, dropdowns and buttons match reference
- [ ] Evidence textarea, confirmation, identity error and disabled submit match reference
- [ ] Completion checkmark and three action cards match reference
- [ ] Added functionality visually integrated without deletion or concealment

## Functionality and accessibility
- [ ] Navigation routes preserved/tested
- [ ] Search, submitted/read-only, draft/edit, save and submit work as intended
- [ ] Required answers/rationale and conditional logic retained
- [ ] Evidence character limit and identity validation work
- [ ] Download/email tested if implemented, otherwise explicitly demo-only
- [ ] Responsive layout tested at desktop and narrower widths
- [ ] Keyboard focus, contrast, labels and error text tested

## Evidence
- [ ] Before/after screenshots saved per screen
- [ ] Control/formula changes logged
- [ ] Deviations and limitations documented
- [ ] Reviewer approval obtained before publishing
