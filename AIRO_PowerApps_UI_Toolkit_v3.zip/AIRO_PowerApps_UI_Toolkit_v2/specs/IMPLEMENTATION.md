# Power Apps Canvas implementation and verification

## 1. App settings
Canvas tablet/desktop, responsive containers, prefer Scale to fit OFF and Lock aspect ratio OFF when supported. Base design width 1536. Screen 1–2 reference height 864, screens 3–5 1024; build scrollable content to avoid clipping. Use modern controls where they reproduce reference and are supported, otherwise classic controls with explicit style. All text must remain native.

## 2. Theme / example Power Fx
At app startup (or named formulas where supported):
```powerfx
Set(gblTheme, {
 HeaderBackground: ColorValue("#1C252F"), Navy: ColorValue("#071849"),
 BodyText: ColorValue("#263A5B"), MutedText: ColorValue("#617493"),
 PrimaryGreen: ColorValue("#007D50"), FioriBlue: ColorValue("#0875E1"),
 PageBackground: ColorValue("#F4F9FF"), CardBackground: Color.White,
 Border: ColorValue("#D9E5F2"), PaleBlue: ColorValue("#EAF3FF"),
 PaleGreen: ColorValue("#EAF8F1"), ErrorRed: ColorValue("#B42318"),
 ErrorBackground: ColorValue("#FDE7E7"), Disabled: ColorValue("#AAB4C6")
});
Set(gblMockMode, true);
Set(gblQMID, "temp00037");
Set(gblAssessmentID, 37);
Set(gblReadOnly, false);
ClearCollect(colAssessments,
 {AssessmentID:37, QMID:"temp00037", Submitter:"Buckwell, Joseph", Team:"Model Risk Office", DateText:"16/10/2026", Status:"Submitted"},
 {AssessmentID:36, QMID:"temp00037", Submitter:"Buckwell, Joseph", Team:"Model Risk Office", DateText:"16/10/2026", Status:"Draft"}
);
```
Power Fx property syntax and control API may vary by Studio version; Copilot must validate all formulas in the live app rather than paste unverified code blindly.

## 3. Navigation / state
`Navigate(scrQmidSearch, ScreenTransition.Fade)` for previous; `Navigate(scrQuestionnaire, ScreenTransition.Fade)` for New; `Navigate(scrEvidence, ScreenTransition.Fade)` on validated questionnaire; `Navigate(scrComplete, ScreenTransition.Fade)` on valid evidence/email. Back controls must preserve draft state. For mock completion actions use `Notify("Demo only — no file was generated", NotificationType.Information)` and analogous email notification.

## 4. Shared header
One reusable component. Use a solid dark background rectangle; optional halftone texture in a separate Image control behind header text, on the right. Left approved logo image; left title label; right 'AIRO Triage'. Responsive header height and typography; test no overlap at 1024 width. Make branding asset and colours component inputs or app-level values.

## 5. Reusable layout
Use auto-layout vertical/horizontal containers and cards; avoid absolute positioning except intentional background art. Tables can be native galleries with aligned columns if Power Apps table control lacks precise styling. `cmpQuestionCard` supports number, title, info text, expanded state, response control slot (or composition), validation, optional rationale flag. Use `If(App.Width < 1000, ...)` or equivalent responsive logic to stack action cards and reduce gutters.

## 6. Screenshot visual QA
At desktop reference widths: verify header height, logo, heading baseline, cards, border radius, whitespace, table columns, text wrapping, button dimensions, colours, progress, and error/disabled states. Target high visual similarity; do not overfit to screenshot text rasterisation. Capture live Power Apps preview screenshots and compare side by side with references. Correct the largest mismatches first; repeat per screen. Include accessibility review and 1024px-width test.

## 7. MCP/skill guardrails
First enumerate actual available Power Apps Canvas skill and MCP capabilities. Do not invent commands, connectors, or permissions. If direct app creation or component editing is unavailable, generate source artifacts/instructions in the repo and explicitly identify manual import steps. Never claim successful changes without read-back from Power Apps Studio/tool. Work in a dev environment and avoid modifying production apps.

## 8. Definition of done
Five accessible, navigable Canvas screens; shared header; replaceable logo and background; central theme; reusable components; mock collections; visible demo-only behaviour for unimplemented external actions; all screens screenshot-reviewed against supplied references; all edits saved and verified in development app.
