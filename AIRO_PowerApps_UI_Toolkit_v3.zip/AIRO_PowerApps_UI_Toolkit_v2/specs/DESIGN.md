# AIRO Triage Design System — SAP Fiori-inspired / AIASO

## Design intent
Enterprise banking UI; visual hierarchy and density inspired by SAP Fiori. This is a bespoke AIASO theme, not a claim of official SAP certification or exact Fiori design tokens. The five screenshots in `../references/` are the primary visual source of truth. The optional upstream SAP DESIGN.md is a secondary source for interaction and layout principles; resolve conflicts in favour of approved screenshots and accessibility.

## Centralised theme tokens (editable)
| Token | Value | Use |
|---|---|---|
| HeaderBackground | `#1C252F` | charcoal header |
| HeaderText | `#FFFFFF` | header typography |
| Navy | `#071849` | primary headings |
| BodyText | `#263A5B` | normal content |
| MutedText | `#617493` | helper text |
| PrimaryGreen | `#007D50` | primary buttons |
| PrimaryGreenHover | `#006B44` | hover |
| FioriBlue | `#0875E1` | link/info icons, question numbers |
| PageBackground | `#F4F9FF` | page canvas |
| CardBackground | `#FFFFFF` | cards |
| Border | `#D9E5F2` | subtle border |
| PaleBlue | `#EAF3FF` | info strips |
| PaleGreen | `#EAF8F1` | success strips |
| ErrorRed | `#B42318` | error text |
| ErrorBackground | `#FDE7E7` | validation banner |
| Disabled | `#AAB4C6` | disabled submit |
| RadiusCard | `12` | card corner |
| RadiusControl | `6` | input/button corner |
| HeaderHeight | `106` | desktop header |
| PageGutter | `40` | desktop horizontal margin |
| CardPadding | `24` | cards |
| BaseFont | `Segoe UI` | native Microsoft-friendly typeface |

Use one central Power Fx record `gblTheme` (or a supported named formula) to define the above tokens. Avoid per-screen hard-coded colours. Derive HoverFill, DisabledFill, and BorderColor from theme. Use a shared `cmpHeader` component on all five screens.

## Header
Height ~106px at 1536 reference width. Dark charcoal/navy background. Left: AIASO blue square logo (about 80×80) and white 'AI Analytics, Strategy & Oversight' text; right: white 'AIRO Triage'. Halftone-dot texture appears subtly on right/centre, behind text; do not rasterise the text into the header background. Keep header consistent across all screens. Replace logo/media via component property, not each screen.

## Typography
Header branding 26–30px semibold; page title 38–48px bold; screen section title 32–38px bold; card title 24–28px bold; body 18–22px; table labels 13–16px. Scale with viewport and use responsive constraints. Use native text labels; never embed functional copy in an image.

## Components
`cmpHeader`, `cmpPrimaryButton`, `cmpSecondaryButton`, `cmpActionCard`, `cmpStatusPill`, `cmpAssessmentTable`, `cmpQuestionCard`, `cmpInfoBanner`, `cmpErrorBanner`, `cmpProgressBar`. Component APIs should accept text, icons/media, colours (default to theme), and OnSelect/behaviour properties where Canvas components support them. If unsupported, use a documented reusable container pattern.

## Interaction states
Default, hover, focus, disabled, error, success. Buttons minimum 44px height. Keyboard and screen-reader labels. Clear tab order. Avoid green-on-green text. Error banners include icon and plain-language message. Ensure sufficient contrast and do not rely on colour alone.

## Asset policy
Use imported PNG/SVG only for logo and decorative texture/background; prefer native Power Apps icons or approved SVG media for icons. Asset references must be centralised so branding is swappable. Do not use full-page screenshot as UI. Never use Lloyds building photo as a screenshot crop in production without confirming rights and approved source; substitute an approved image while retaining composition.

## Version 2: three-mode usage and future features
This design system applies equally to blank builds, existing-app modernisation and post-feature-change visual refinement. Approved reference images define baseline visual style, **not a limit on permitted functionality**. Preserve newly added fields and behaviours and apply the same tokens/components. Maintain logo, texture, page imagery and approved Lloyds media as separately replaceable assets using `config/asset-manifest.json`. Central theme source: `config/theme.tokens.json`, translated to Power Fx per `config/POWER_FX_THEME.md`.

## v3 — Screen-specific background policy
Use **two centrally replaceable backgrounds**. `HOME_BACKGROUND` (`assets/backgrounds/airo_home_background.png`) is exclusive to `scrHome`. `CONTENT_BACKGROUND` (`assets/backgrounds/airo_content_background.png`) is shared by `scrQmidSearch`, `scrQuestionnaire`, `scrEvidence`, and `scrComplete`. Both are decorative Image controls positioned below the reusable header and behind native UI. Do not use the building hero on form/table pages. See `assets/BACKGROUNDS.md` and `config/backgrounds.json`. The home artwork requires bank approval or replacement for production.
