# Visual modernisation and feature evolution policy

**Never sacrifice functionality for screenshot similarity.** Screenshots represent the baseline visual style and baseline controls, not a frozen functional scope.

Change classification:
- V: visual-only (colour, spacing, font, border, icon, decorative media) → apply with screenshot QA.
- L: layout change (reordering, containers, responsiveness) → inspect formulas, visibility and focus before edits.
- F: functional change (new fields, validation, status, flow, persistence) → preserve or implement only from approved requirements; test separately.
- B: branding/theme change → update tokens/assets centrally; regression check all screens.

For every request: capture current state, identify delta, inventory affected controls and dependencies, map new elements to components, implement in development copy, verify formulas and data behaviour, screenshot test, document deviations. If existing functionality conflicts with reference, keep functionality and raise a visual design decision. Do not silently hide controls or make required fields optional. Mark assumptions explicitly.

Acceptance levels: (1) functional parity (mandatory), (2) branding/theme consistency (mandatory), (3) visual fidelity to approved references where functionally applicable (target), (4) accessibility and responsive behaviour (mandatory). Avoid claiming pixel-perfect equivalence when Power Apps platform constraints prevent it.
