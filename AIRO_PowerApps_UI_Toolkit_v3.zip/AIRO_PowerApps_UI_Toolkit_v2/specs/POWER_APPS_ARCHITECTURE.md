# Power Apps implementation architecture

## Recommended app structure
Screens: `scrHome`, `scrQmidSearch`, `scrQuestionnaire`, `scrEvidence`, `scrComplete`. Existing app may have different names: **do not rename without checking formulas and references**. Shared theme in named formulas (if enabled/supported) or `App.OnStart` variable; shared header component; galleries for dynamic assessments/questions; auto-layout containers for page sections. Data/behaviour separated from visual styles.

## Implementation capability gate
1. Enumerate available Power Apps skills/MCP actions and verify read/edit/create/import/export support.
2. Determine whether work will be through live Canvas Studio, source representation (Power Apps source code / supported unpack-pack workflows), or a hybrid. Use only officially supported methods for the environment; do not assume a plain YAML edit can safely be deployed.
3. For existing app, inventory screen/control names, component library, App.Formulas/OnStart, OnSelect, OnChange, Items, Default, DisplayMode, Visible, Navigate, Patch/SubmitForm, Flow.Run, collections, connections, roles and permissions.
4. Keep a backup and a mapping of pre/post formulas. Capture screenshots before and after.
5. If direct edit unsupported, generate exact property-change instructions or supported source edits for a developer to apply; never report edits as completed when they were only proposed.

## Mode separation
- **Blank build:** mock local data and clearly labelled demo actions; no external connections required.
- **Existing modernisation:** preserve formula bindings, screen routes, IDs, controls and data source schemas. Update visual properties first; replace controls only after dependency analysis and approval.
- **Evolved UI refinement:** discover newly added functionality; map new elements into existing visual component contracts; keep all behaviour; update references/specs only when approved changes affect layout.

## Navigation and validation
Navigation actions remain native Power Fx; in UI-only demo use local variables and Notify for unimplemented actions. In existing app, do not replace working persistence with mock data. Email identity validation should use authenticated user identity where policy requires; do not hardcode demo email. Keep rationale requirements configuration-driven and retain mandatory checks when present.

## Visual asset architecture
Store approved media in app Media. Provide central alias/lookup or component media inputs for `BrandLogo`, `HeaderTexture`, `PageBackground`, `LloydsLogo`, `BuildingPhoto`; replace media centrally. No text, controls or tables embedded in decorative raster backgrounds. Use asset manifest for provenance and replacement.
