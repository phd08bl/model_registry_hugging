# Reusable visual component contracts

Prefer a small component library with documented input properties and output/behaviour events where supported by the Canvas component model. **Do not move a working OnSelect formula into a component without verifying event/property support.** Where component limitations prevent safe reuse, use a documented container template and shared token formulas.

| Component | Contract | States / variants | Notes |
|---|---|---|---|
| `cmpHeader` | logo media, product title, organisation name, background media, height | desktop, compact | same across all screens; brand copy is live text |
| `cmpPrimaryButton` | label, icon, disabled, action hook | default, hover, pressed, disabled, focus | preserve host control's OnSelect in existing apps |
| `cmpSecondaryButton` | label, icon, action hook | outlined, back, focus | consistent border |
| `cmpActionCard` | icon, heading, description, action label | home, completion | action area min 44px high |
| `cmpQuestionCard` | number, question, help, answer slot, rationale slot | unanswered, answered, error, read-only | never embed question/answer in images |
| `cmpStatusPill` | status text | submitted, draft, other | icon/text accompany colour |
| `cmpAssessmentTable` | column configuration, rows, row action | empty, loading, populated, error | native gallery preferable for responsive layout |
| `cmpBanner` | message, icon, severity | info, success, error, warning | accessible text |
| `cmpProgressBar` | completed, total | empty, partial, complete | computed from data, not static screenshot |
| `cmpField` | label, help, required, validation message | default, focused, invalid, disabled | input type controlled by host screen |

## Rules for added features
New controls must reuse tokens for spacing, borders, typography and colour; maintain existing data contracts and validation. Examples: conditional mandatory rationale textarea beneath a question; reviewer comments; attachment list; approval state; additional questionnaire section; conditional multi-select. Add variants to existing components where possible rather than cloning entire screens. Track every addition in `templates/FEATURE_EXTENSION.md`.

## Responsive layout
Reference target is ~1536px-wide desktop. Use auto-layout containers and parent-relative dimensions, sensible min/max widths, flexible galleries and vertical scrolling. On narrow viewports stack action cards and table rows; preserve keyboard navigation and focus. Never place functional content under a decorative image. Avoid fixed-position controls that clip on mobile.
