# AIRO Backgrounds — Two-Background Policy (v3)

## Included assets

| Alias | File | Screens | Purpose |
|---|---|---|---|
| `HOME_BACKGROUND` | `assets/backgrounds/airo_home_background.png` | `scrHome` | Lloyds-building hero artwork with decorative waves and dots |
| `CONTENT_BACKGROUND` | `assets/backgrounds/airo_content_background.png` | `scrQmidSearch`, `scrQuestionnaire`, `scrEvidence`, `scrComplete` | Minimal pale blue-white backdrop for legible forms and tables |
| `PAGE_BACKGROUND` | `assets/page_background.png` | Legacy fallback | Prior simple gradient; retained for compatibility |

**Why two?** The prominent building artwork suits the landing screen but competes with dense questionnaire, tables, errors and evidence forms. Content pages should use a consistent quiet background.

## Power Apps import and usage

1. In Canvas Studio open **Media > Upload**, and upload the two PNGs. Confirm their actual media identifiers. Suggested names: `airo_home_background` and `airo_content_background`.
2. Add a background Image control on each screen, behind every other element. For home set `Image = airo_home_background`; on the other four set `Image = airo_content_background`.
3. Set `X = 0`, `Y = cmpHeader.Height` (or `gblTheme.HeaderHeight`), `Width = Parent.Width`, `Height = Parent.Height - Self.Y`, `ImagePosition = ImagePosition.Fill`. The image must not cover the header. If a component height is unavailable, use the theme token.
4. Use **Reorder > Send to back** and keep inputs/buttons as native controls above the image. If backgrounds appear stretched, compare `ImagePosition.Fill` vs `ImagePosition.Fit` and choose the approved result at target aspect ratio.
5. To change branding later, replace the media file and update the two central aliases/media bindings; do not recreate the screens. Keep the header logo independent.

## Layout and accessibility

Do not bake header, titles, forms, buttons or text into background artwork. Use opaque/semi-opaque white cards for dense content. Verify readability at 1536x864 and the actual app viewport, including responsive scaling. Use the screenshots in `references/` for layout, not as a flattened UI.

## Approval note

The home hero artwork is AI-generated, including an approximation of the Lloyds building and mark. It is **not an official brand master or a verified bank-approved photograph**. Obtain brand/legal approval or replace with approved photography before production.
