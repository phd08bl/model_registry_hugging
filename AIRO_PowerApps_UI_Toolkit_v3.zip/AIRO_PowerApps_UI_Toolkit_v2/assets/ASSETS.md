# Replaceable media manifest

- `aiaso_logo_reference_crop.png`: temporary logo crop from screenshot, **not an approved production logo**. Replace with transparent official AIASO logo. Update the media reference in `cmpHeader` only.
- `header_halftone_reference_crop.png`: temporary subtle halftone texture reference. Use only as decoration, overlay on charcoal header. Prefer approved full-width source asset.
- `page_background.png`: simple clean pale blue gradient; optional; native Fill may be preferable for performance.
- Lloyds building photograph: **not supplied as a standalone asset**; do not crop it from the whole UI screenshot for production. Obtain approved photo, then use a replaceable image control on Home screen.
- Lloyds logo: **not supplied as standalone approved asset**; obtain approved logo or use temporary clearly labelled placeholder in Questionnaire.
- Icons: prefer Power Apps native icons or approved SVGs, not screenshot crops.

## v2 asset replacement
Use `../config/asset-manifest.json` to track aliases and approved source files. Replace temporary logo reference crop with an approved master before production. The building photo and Lloyds logo are **not provided** as independent approved assets. The five screenshots must not be used as clickable UI layers.

## v3 included screen backgrounds
- `backgrounds/airo_home_background.png`: generated Lloyds-building hero composite for Home only; brand approval required.
- `backgrounds/airo_content_background.png`: subtle background for all four workflow screens.
- Import instructions and positioning: `BACKGROUNDS.md`. The old `page_background.png` remains available as a fallback.
