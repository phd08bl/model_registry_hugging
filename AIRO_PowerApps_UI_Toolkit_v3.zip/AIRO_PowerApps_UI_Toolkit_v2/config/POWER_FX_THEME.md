# Power Fx theme translation

`theme.tokens.json` is a design source of truth, **not an automatically imported Power Apps theme**. Apply the tokens to named formulas where supported, otherwise use `App.OnStart` and set the record. Example:

```powerfx
Set(gblTheme, {
    HeaderBackground: ColorValue("#1C252F"),
    Navy: ColorValue("#071849"),
    PrimaryGreen: ColorValue("#007D50"),
    PrimaryGreenHover: ColorValue("#006B44"),
    FioriBlue: ColorValue("#0875E1"),
    PageBackground: ColorValue("#F4F9FF"),
    CardBackground: ColorValue("#FFFFFF"),
    Border: ColorValue("#D9E5F2"),
    ErrorRed: ColorValue("#B42318"),
    RadiusCard: 12,
    RadiusControl: 6,
    HeaderHeight: 106
})
```

Apply `Fill = gblTheme.PrimaryGreen`, `Color = Color.White`, `HoverFill = gblTheme.PrimaryGreenHover` on primary actions where those properties are supported. Some modern controls expose different properties or theme APIs; verify against actual control types. Preserve `OnSelect`, `Items`, `Default`, `Visible`, `DisplayMode` and validation formulas in existing apps unless changes are explicitly approved. Theme token changes require a five-screen visual regression pass.
