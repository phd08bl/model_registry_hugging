# AIRO Power Apps UI Design & Modernisation Toolkit v2.0

**Purpose:** One reusable, AIASO-branded SAP Fiori-inspired visual system for (A) a new five-screen Canvas app, (B) safe visual modernisation of an existing Canvas app, and (C) ongoing styling of changed or added functionality.

## Quick start
1. Review `references/` (approved visual targets), `specs/DESIGN.md` (tokens), `specs/SCREENS.md` (screen contracts), and `assets/ASSETS.md` (approved media requirements).
2. Choose **exactly one mode**: `prompts/01_BUILD_FROM_BLANK.md`, `prompts/02_MODERNISE_EXISTING.md`, or `prompts/03_REFINE_EVOLVED_UI.md`.
3. Connect GitHub Copilot CLI to the team's existing Power Apps Canvas skills/MCP; have it inventory *actual* supported operations first. Do not assume it can directly create/edit every control or export source.
4. For existing apps: create a separate development copy and backup/export; run discovery and request approval before edits.
5. Apply shared theme and header first, then one screen at a time. Compare actual runtime screenshots against references and run tests in `qa/`.

## Directory
- `references/`: five approved UI screenshots (visual benchmark, NOT app backgrounds).
- `assets/`: replaceable logo and decorative images; cropped reference logo is **not** production artwork.
- `specs/DESIGN.md`: central design language and tokens.
- `specs/SCREENS.md`: baseline screen content, interaction and reference mapping.
- `specs/COMPONENTS.md`: reusable component contracts, responsive behaviour, extensibility.
- `specs/POWER_APPS_ARCHITECTURE.md`: Canvas-specific implementation patterns and constraints.
- `specs/CHANGE_POLICY.md`: preserve behaviour, apply styling to newly added features.
- `config/theme.tokens.json`: platform-neutral design tokens; Power Fx translation is in `config/POWER_FX_THEME.md`.
- `config/asset-manifest.json`: swappable media aliases, source/provenance notes.
- `prompts/`: three entry prompts, common quality gate, and per-screen iteration.
- `templates/`: app discovery, control mapping, change request, screen extension and decision log.
- `qa/`: visual, functional and regression acceptance checklists.

## Precedence and guardrails
**Functional correctness, bank controls, accessibility > current approved business requirements > existing live app behaviour > five screenshot visuals > optional upstream SAP design guide.** For purely visual decisions, approved screenshots lead; `DESIGN.md` generalises their visual language. If screenshots omit newly implemented controls, keep the controls and apply the shared style rather than deleting them.

No SharePoint schema changes, backend deployments, Power Automate flow changes, production publishing or removal of controls without explicit approval. Treat IDs, email, dates, records and example dropdown values as demo data, not production data. Do not claim email/download works without a verified integration. Obtain permission to use bank logos and photographs. SAP Fiori-inspired is a stylistic description, not SAP certification.

## Suggested workflow
Discovery → choose mode → design/functional mapping → implementation plan and approval → development implementation → screenshot comparison → regression checks → sign-off. Store decisions in `templates/DECISION_LOG.md`.

## v3: background assets now included
The toolkit now includes two importable PNG files: `assets/backgrounds/airo_home_background.png` (Home only) and `assets/backgrounds/airo_content_background.png` (all four other screens). Read `assets/BACKGROUNDS.md` for Studio steps, `config/backgrounds.json` for screen mapping, and `prompts/05_APPLY_BACKGROUNDS.md` for a Copilot task. The original background remains as a fallback. Replace the generated Lloyds artwork with bank-approved photography before production.
