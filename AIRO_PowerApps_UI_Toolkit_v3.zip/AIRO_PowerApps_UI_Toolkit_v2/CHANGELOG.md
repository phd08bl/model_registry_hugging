# Changelog

## v3 — 2026-10-17
- Added dedicated home hero background featuring AI-generated Lloyds-building artwork.
- Added low-distraction content background for the four workflow pages.
- Added `assets/BACKGROUNDS.md`, `config/backgrounds.json`, and Copilot prompt `prompts/05_APPLY_BACKGROUNDS.md`.
- Updated asset manifest, design specification, and README.
- Preserved v2 references, prompts, architecture, existing fallback background, and theme tokens.
