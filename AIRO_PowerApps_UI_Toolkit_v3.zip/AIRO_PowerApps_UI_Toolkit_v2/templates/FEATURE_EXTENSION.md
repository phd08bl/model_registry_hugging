# New feature design extension

- Feature / screen / owner / approval:
- What was added or changed:
- Classification: V / L / F / B
- Existing functionality and formula dependencies to protect:
- Component variant or new component needed:
- Design tokens used (colour, typography, spacing, radius):
- Field validation / required rationale / read-only / disabled states:
- Responsive layout and accessibility:
- Reference baseline region (if applicable):
- Visual acceptance evidence:
- Functional regression test:
- Deviations / decisions:
