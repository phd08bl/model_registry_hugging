# Existing app discovery template

- Environment / app name / app ID (internal only):
- Development copy / backup / export location:
- MCP skills/actions actually available:
- Screen inventory (actual name → baseline reference → additional features):
- Components / media:
- Theme location:
- Connections / SharePoint / flows (names only; no secrets):
- Critical Power Fx actions / dependencies:
- Authentication / permissions:
- Responsive / accessibility limitations:
- Functional risks:
- Proposed visual changes:
- Approval / owner / date:
